#! /bin/bash

function dt () {
	date +"%b_%d_%Y_%H" | sed s/_0/_/g
}

function DocScr() {

	zenity --info --text="Welcome to DocSrc Beta. Please press OK and enter details to proceed" --title="DocSrc Beta"
	usname=$(zenity --entry --text="Please enter your username for logging" title="DocScr Beta")
	echo "User " $usname >> /APF/Sumanth/DocScr/DocSrclog/.log_`dt`

	selecttask=$(zenity --list --column="Select your task" "RUN-SINGLE-QUERIES" "RUN-BATCHMODE" "RUN-SINGLE-QUERIES" "PUB-SCRAPE" "COMMANDS-HELP" --title="DocSrc Beta")

	if [ $selecttask == "RUN-TEST-DOCSCR" ];then
		. .modules.sh
		cp /APF/Sumanth/DocScr/.GDD.py .
		cp /APF/Sumanth/DocScr/liquidlist .
		printf "DocScr Initialized Please start process from File or Wlink"
	
	else
		if [ $selecttask == "RUN-BATCHMODE" ]; then
		. .modules.sh
		cp /APF/Sumanth/DocScr/.GDD.py .
		cp /APF/Sumanth/DocScr/liquidlist .
		echo "DocScr Initialized"

		batch_directory=$(zenity --entry --text="Please enter the batch raw files location" title="DocScr Beta")
		find $batch_directory > workinglist
		
		while IFS='' read -r line || [[ -n "$line" ]]; do
			process loc "$line"
			name=$(name_identifiers)
			title=$(titles_identifiers)
			qualification=$(qualification_identifiers)
			specialt=$(specialization_identifiers)
			certif=$(certification_identifiers)
			relevence=$(cwrelevence)
			phone=$(access_details phone)
			fax=$(access_details fax)
			address=$(onsite_access c)

			printf "$name#$title#$qualification#$specialt#$certif#$relevence#$phone#$fax#$address" >> Report_batch_`dt`.xlsx
		done < workinglist

		ls $batch_directory | sed "s|\-|\_|g" | sed "s|md$||g" > Doctors_List_batch_`dt`
		zenity --text-info --filename="Doctors_List_batch_`dt`" --title="Doctors List Scraped in Batch"
		zenity --info --text="Process Completed. Data stored in Report" --title="DocSrc Beta"
		else
			echo "NM"
		fi

	fi

}
